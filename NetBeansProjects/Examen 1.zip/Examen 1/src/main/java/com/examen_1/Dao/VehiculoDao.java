package com.examen_1.Dao;



import com.examen_1.domain.Vehiculo;
import org.springframework.data.repository.CrudRepository;


public interface VehiculoDao extends CrudRepository<Vehiculo, Long>{
    
}
